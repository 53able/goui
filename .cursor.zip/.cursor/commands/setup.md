# setup

プロジェクトの初期セットアップを実行する

---

## Task 0: 前提条件の確認

### pnpm のインストール確認

```bash
pnpm --version
```

インストールされていない場合は以下のいずれかでインストール：

**方法1: Homebrew（推奨）**
```bash
brew install pnpm
```

**方法2: スタンドアロンスクリプト**
```bash
curl -fsSL https://get.pnpm.io/install.sh | sh -
```

**方法3: Corepack（Node.js 16.13以降）**
```bash
npm install --global corepack@latest
corepack enable pnpm
corepack use pnpm@latest-10
```

**方法4: npm**
```bash
npm install -g pnpm@latest-10
```

> 📝 参考: [pnpm公式インストールガイド](https://pnpm.io/ja/installation)

---

## Task 1: Gitリポジトリ初期化

```bash
# Gitリポジトリ初期化
git init
git branch -M main

# .gitignoreの作成（なければ）
cat << 'EOF' > .gitignore
# Dependencies
node_modules/
.pnpm-store/

# Build output
dist/
build/

# Environment
.env
.env.local
.env.*.local

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Testing
coverage/

# Temporary
tmp/
*.log

# Vite
.vite/

# TypeScript
*.tsbuildinfo
EOF

# 初期コミット
git add .
git commit -m "chore: initial project setup"
```

> 💡 リモートリポジトリへの接続: `git remote add origin <URL>`

---

## Task 2: 依存関係インストール

```bash
# 依存関係インストール
pnpm install

# 環境変数ファイルの作成
cp .env.example .env
```

### 🔐 API認証情報の設定

`.env` ファイルを編集して、Basic認証の認証情報を設定：

```bash
# .env
BASIC_AUTH_USERNAME=your_username  # ← 任意のユーザー名に変更
BASIC_AUTH_PASSWORD=your_password  # ← 安全なパスワードに変更
```

> 📖 認証の詳細（デフォルト値・認証範囲）は **project.mdc「🔐 API Authentication」** を参照

```bash
# コミット
git add .
git commit -m "chore: install dependencies"
```

> 💡 `.env` ファイルは `.gitignore` に含まれているため、コミットされません。

---

## Task 3: 動作確認

```bash
# 型チェック（tsgo使用） + Lint + テスト
pnpm typecheck && pnpm lint && pnpm test

# 開発サーバー起動
pnpm dev
```

> 💡 `pnpm typecheck` は tsgo（TypeScript Go native）を使用。従来のtscは `pnpm typecheck:tsc` で実行可能。

---

## 開発時の起動

```bash
# ターミナル1: バックエンド（Hono）
pnpm api:dev

# ターミナル2: フロントエンド（Vite）
pnpm dev
```

> 📖 ポート・URL情報は **project.mdc「🚦 Endpoints」** を参照

### curlでのAPI呼び出し例

```bash
# 認証情報はデフォルト値（開発用）
curl -u admin:admin http://localhost:3000/api/v1/users
```

---

## 本番環境の起動

```bash
# ビルド
pnpm build

# 本番サーバー起動（全画面認証）
pnpm start
```

> 📖 本番環境の認証範囲は **project.mdc「🔐 API Authentication」** を参照

---

## コマンド早見表

| カテゴリ | コマンド | 用途 |
|---------|---------|------|
| **Setup** | `pnpm install` | 依存関係インストール |
| **Dev** | `pnpm dev` | フロントエンド開発サーバー |
| **Dev** | `pnpm api:dev` | バックエンド開発サーバー |
| **Production** | `pnpm build` | プロダクションビルド |
| **Production** | `pnpm start` | 本番サーバー起動 |
| **Quality** | `pnpm typecheck` | 型チェック（tsgo - 高速） |
| **Quality** | `pnpm typecheck:tsc` | 型チェック（tsc - 互換用） |
| **Quality** | `pnpm lint` | Linting（Biome） |
| **Quality** | `pnpm test` | テスト実行（Vitest） |
| **Quality** | `pnpm check` | 型チェック + Lint |

> 📖 コミット前の必須チェックは **project.mdc「✅ Quality Gates」** を参照
